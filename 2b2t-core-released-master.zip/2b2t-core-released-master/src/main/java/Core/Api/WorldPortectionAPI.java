/* Copyright (C) 2B2TMCBE™ - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by maxxie114 <maxxie114@mxpersonal.com>, Feb 8, 2019
 */
package Core.Api;

public class WorldPortectionAPI {

  /**
   * 
   */
  public WorldPortectionAPI() {
    // TODO Auto-generated constructor stub
  }

}
